# AVION API 17: handoff to the host application

The DLL is `build\Release\avion.dll`; `media_api_version()` returns 17. API 16's calls are unchanged, so code written for API 16
keeps working. The reference is `docs\sdk-reference.md`, and `docs\matroska.md` covers the new containers and AV1. The Python
wheel and the NuGet package are at API 17.

## What plays now that did not

Probe first, as before. `media_probe` now reports MKV/WebM tracks and AV1 as playable when they are.

| File | API 16 | API 17 |
|---|---|---|
| `av_sync_clock_45m.mp4` (4K60 AV1, 45 min) | refused, stage 4 | **plays**: Windows' own AV1 decoder; 0 dropped in 12 of 12 consecutive runs (the MKV copy: 10 of 10); both test seeks exact |
| `.mkv` with H.264 / HEVC (Main, Main 10) and AAC | `playable = 0` | **plays**: 0 dropped, 0 allocations |
| `.webm` with AV1 and Opus (YouTube, a browser's MediaRecorder) | `playable = 0` | **plays**, including live-style files (clusters of unknown size) |
| `.mkv` with Opus | `playable = 0` | **plays**: Opus mono or stereo, through Windows' decoder |
| Embedded subtitles in MKV (SRT text, WebVTT, ASS/SSA) | not read | **listed and shown**; ASS styling is dropped, the text kept |
| MKV chapters | not read | **used**: the dock's marks, "next chapter" |

Still refused, so these go to mpv as before: VP9 and VP8, AC-3/E-AC-3, DTS, FLAC, Vorbis, multichannel Opus, PGS and VobSub
subtitles, and Matroska tracks with compressed or encrypted frames. `media_probe` says which applies.

### AV1 runs on the CPU here

The machine's GPU (Intel UHD 630) has no AV1 decoder. The author authorised the platform's software decoder for this case
(docs/ENGINE_MANIFESTO.md, 2E), so it is used:

- 4K60 AV1 takes about 4 cores of CPU, about 400 % in Task Manager terms. H.264 and HEVC stay on the GPU at a few percent.
- `media_query_video_decoder` reports it.
- If you show a "hardware decoding" badge, do not show it for AV1.
- On a PC without the AV1 Video Extension (Microsoft Store), `media_probe` says AV1 is not playable, and you fall back as before.

### Matroska seeks use the Cues (new in this update)

A Matroska file is still indexed by one read of the whole file while it plays (a 1.4 GB file: 0.46 s from the system's
cache). A seek no longer waits for that read when the file has Cues. ffmpeg, mkvmerge and HandBrake write them, usually at
the end. The demuxer finds them through the SeekHead and reads only them (65,678 bytes of a 657,424-byte test file), then
seeks to the last cue at or before the target and continues from that cluster's first key frame. On the test file, over a
source that reads only on demand, a seek to 2.5 s right after open lands on the key frame at 2.000 s and reads 262 KB for
its first 20 packets. A live-style WebM (no Cues) is indexed as it is read and becomes seekable when that read ends.

What still waits for the complete index: the timeline's scene marks and the precise intra-GOP continuation.

- Local MKV: nothing to do; seeking works from the start.
- Remote (HTTP) MKV, including Google Drive or S3 with `http_headers`: **verified end to end (Golden Master, 2026-11-09)**. See
  "Golden Master" below.

## New calls

1. **Tracks in host mode.** `media_engine_track_count` / `media_engine_track_info` and the two track controls
   (`MEDIA_CONTROL_AUDIO_TRACK`, `MEDIA_CONTROL_SUBTITLE_TRACK`) now work in `MEDIA_PLAYBACK_HOST` too.
   - In the windowed engine they work as in API 16.
   - Matroska tracks report their MP4 codec names: `avc1`, `hvc1`, `av01`, `mp4a`, `Opus`, `text`, `ssa`.
2. **`media_engine_snapshot_to_memory(e, &buffer)`**: the picture `media_engine_save_snapshot` would write, into your buffer.
   - Formats: BGRA8 or RGBA8, alpha 255, `stride` of your choice. The frame hash is the BMP's.
   - Synchronous in both modes.
   - In the windowed engine, call it from your own thread, not from an `on_frame` callback: the window's thread makes it, and
     from that thread the call returns `MEDIA_ERROR_STATE`.
   - A buffer that is too small returns `MEDIA_ERROR_STORAGE` with `width` and `height` filled in. Allocate
     `width * height * 4` bytes and call again.
3. **`media_engine_attach_subtitles(e, "film.srt")`**: an .srt or .vtt file of up to 4 MiB, loaded while playing. It becomes
   the sidecar (track id 0) and is shown; the file's own subtitle tracks stay.
   - **Both modes, including the windowed engine and `parent_window` embedding (new in this update).** The subtitle renderer
     is prepared at open even when the file has no subtitles, and the new file is swapped in between two passes of the
     window's thread: no allocation, no dropped picture.
   - Windowed errors: `MEDIA_ERROR_STATE` if the previous attach is still being taken, `MEDIA_ERROR_PLAYBACK` if the window's
     thread did not take it within 3 s. `MEDIA_ERROR_OPEN` (unreadable, no cue) leaves the shown subtitles unchanged.
4. **New stages** in `media_engine_last_error_text`: 40 (the platform's AV1 decoder could not be prepared) and 41 (it failed
   while playing).

## What to change in the app

- Stop sending `.mkv` / `.webm` / AV1 to mpv when `media_probe` says `playable = 1`. Keep the fallback for `playable = 0`.
- Remote (HTTP) Matroska with B-pictures: verified end to end (below). It can leave mpv like local files.
- If the app embeds AVION in its window (`parent_window`), call `media_engine_attach_subtitles` while playing; no reopen.

## Final audit (2026-11-10)

- **HEVC Main10 MKV seeks.** `hevc10_aac.mkv` lands on 0.600 s exactly (3 of 3 runs, 0 out of order). The 9 November report said
  it had landed on 0.567 s: that was wrong. It mixed up the H.264 file's run from before the fix. The run of `hevc10_aac.mkv` after
  the fix already landed on 0.600 s. The case is now a permanent test: `media_fixture_mkv_hevc10_bframes_seek_test`.
- **Licence files.** `LICENSE` is the verbatim GNU AGPLv3, which GitHub's detector matches. `LICENSING.md` holds the dual
  licence and the commercial option; it replaces `LICENSE.md` and `COPYING`. The terms are unchanged. The packages and the
  bundle carry `LICENSE` and `LICENSING.md`.
- **Test files.** The reported mpv file (zero-duration last sample) stays private. The test that every clone runs uses a
  synthetic twin, `compat/stts_last_zero.mp4`, made by `make_compat_matrix.py` with the same structure (B-pictures in a 24000
  timescale, 44.1 kHz mono AAC, `stts` ending `(1, 0)`). Generating it twice gives the same bytes.
- **Third-party footage.** Tests that need it (the LG, Costa Rica and Dolby reels, Big Buck Bunny 4K, the 45-minute clock) are
  now registered only when the file is present, so a clean clone of the repository skips nothing.
- Verified: MSVC Release **246 of 246** (1,455 s) and Debug **246 of 246** (2,326 s), none skipped, with Chrome decoding a
  1080p video on the iGPU (121 of 124 samples, 1.1-10.6 %). GCC 13.3 (`-O2` and ASan/UBSan, `tools/linux/gcc.sh`): **102 of 102**.

## Golden Master (2026-11-09): MKV with B-pictures, local and over HTTP

**Fixed: the picture out of order after a seek in an MKV with B-pictures.** Matroska stores times rounded to 1 ms. With the
track's DefaultDuration (33.333 ms) the picture stored at 1.667 s still "covered" 1.700 s, so after a seek to 1.700 s both were
shown: the landing, then the earlier B-picture, rejected as late. A backward seek to 0.600 s landed on 0.567 s. Each video frame's
duration is now the gap to the next presentation time, from the pictures decoded before and after it. Both seeks now land on
the exact picture, with 0 out of order, for H.264 and HEVC, from the file and over HTTP. Nothing changes in your app.

**End to end over HTTP** (`media_http_mkv_seek_test`). The file is 10 minutes of 720p H.264 with B-pictures, 198 MB, with its
Cues at the end. The test server refuses (401) any request without the token header, and the engine sends it through
`http_headers` (what `media_engine_open_ex` passes), as for a Drive or S3 link. The test makes five seeks (400.5 s, 120.25 s, 530.4 s
paused, 121.7 s, 595.3 s) and plays to the end:

| | Result |
|---|---|
| Landings | 5 of 5 on the exact picture, sound within one sample; 26-30 ms from request to picture |
| Pictures | 0 dropped, 0 out of order, 0 allocations |
| Network | 0 unauthorized, 0 failed; the Cues read as one 8.5 KB range at the end; 69 MB of 198 MB read in total |
| Timeline | the full 600 s duration known at open, before any index |

**Less read per seek.** After a seek, the engine now reads one 8 MiB chunk ahead instead of two, and goes back to two once
playback reads on. On that test the total fell from 102 MB to 69 MB with the same seek times. This matters for metered Drive
or S3 traffic.

**Licence.** From this release AVION is dual-licensed: GNU AGPLv3, or a commercial licence. The source is public at
https://github.com/5645hm-a11y/avion. An app that ships AVION inside closed-source software needs the commercial licence (contact
Alexandre Heymann). An AGPLv3 app does not. The packages' metadata now say `AGPL-3.0-only OR LicenseRef-AVION-Commercial`.

### Verified (2026-11-09, Golden Master)

- MSVC x64 `/W4 /WX`, CTest serial, 243 tests (239 before, plus the three MKV seek tests and `media_http_mkv_seek_test`). Chrome
  played a 1080p video on the same iGPU throughout; its share of the video-decode engine was sampled every 30 s (`build/bench/golden/gpu_load.txt`): decoding in 126 of 129 samples, 0.8-10.5 %, median 6 %.
  - Release: **243 of 243** passed, none skipped (1,414 s).
  - Debug: **243 of 243** passed, none skipped (2,298 s).
  - An earlier Release run had four failures. `media_nuget_package_test` was a real one: the test still expected the old licence
    metadata, and it was updated. The other three each dropped one picture behind a 21-63 ms whole-process stall while the
    publication files were being copied; all four passed when run alone. In that run the browser had also stopped decoding
    partway through. The load page now restarts its video by itself, and the decode load is logged.
- GCC 13.3 (`-O2` and ASan/UBSan, `tools/linux/gcc.sh` as published): 51 builds, **102 of 102** result lines passing.

## Verified (2026-11-05, earlier API 17 update)

- MSVC x64 `/W4 /WX`, CTest serial, with Chrome playing a 1080p video on the same iGPU for the whole run (its video-decode
  engine at 8-10 %):
  - Release: **239 of 239** passed, none skipped (1,398 s).
  - Debug: **239 of 239** passed, none skipped (2,256 s).
- Under a heavier browser load, Chrome playing a 4K60 HEVC video (video-decode engine about 62 %), an earlier build passed
  Release 239/239. Debug failed two tests:
  - `media_fixture_av1_4k60_test`: the worker's CPU bound, now 0.95 of a core for a software decoder.
  - `media_fixture_subtitle_search_test`: one picture dropped at a 4K60 HEVC seek landing. That test passes 5 of 5 with the
    browser closed and 1 of 5 with it decoding 4K60 HEVC. Two 4K60 HEVC streams at once exceed the UHD 630's video decoder:
    that is the hardware's limit, not a regression.
- GCC 13.3 (`-O2` and ASan/UBSan): 51 builds, **102 of 102** result lines passing (the Matroska demuxer with the Cues seek among them).
- Windowed attach: `media_fixture_attach_mp4_test` and `media_fixture_attach_mkv_test` (attach at 1 s from another thread,
  a file without a cue refused at 2 s, a .vtt replacing the .srt at 3 s: captions drawn, 0 dropped, 0 allocations), and
  `media_embed_tests` through `avion.dll`.
- 4K60 AV1 on the CPU: 0 dropped in 12 of 12 consecutive runs of the .mp4 and 10 of 10 of the .mkv (before the fixes, 7 of 10
  runs dropped one or two pictures). The decoder was never behind. There were three causes: the transform's threads
  delaying the presentation thread, a pause the worker answered up to 31 ms late, and a controls-only image drawn just
  before a picture the clock had not yet timed. `docs/matroska.md` has the details.
- Found then, fixed on 2026-11-09 (above): `--test-seek` on `h264_aac_srt_chapters.mkv` (B-pictures) reported one picture out
  of order after a seek.

## Verified (first API 17 build, 2026-11-05 morning)

- MSVC x64 `/W4 /WX`:
  - Release: 236 of 237 in the final full run (1,382 s, serial). The one failure was `media_fixture_mkv_av1_4k60_test`: one AV1 picture dropped at 5.92 s (the CPU path; see below). An earlier full run was 233/237; its four failures were fixed and pass: the AV1 refusal test (AV1 now plays), the Python struct size, a test race and a perception arena size.
  - Debug: 236 of 237 (2,222 s, serial). The one failure was `media_host_tracks_tests`: the attach opened its file through stdio, and the CRT allocates a FILE. It now reads through the OS directly: 0 allocations, and it passes in Debug and Release.
- GCC 13.3 (`-O2` and ASan/UBSan): 51 builds, 102 result lines, all passing (the Matroska demuxer and the host-tracks C test under ASan/UBSan among them).
- New tests:
  - `media_matroska_demux_tests` (real files, plus about 10,000 corrupted and cut ones)
  - nine `media_fixture_mkv_*` / `_webm_*` / `_av1_*` playback tests
  - `media_host_tracks_tests` (C99, both platforms)
  - the windowed memory snapshot in `media_snapshot_tests`
- AV1 4K60 drops: with the deeper pre-roll for the software decoder, 10 consecutive runs alone: the MP4 5/5 with nothing dropped, the MKV 4/5 (one picture at 0.033 s, during the cold start). So the CPU path is not drop-free in every run yet.
