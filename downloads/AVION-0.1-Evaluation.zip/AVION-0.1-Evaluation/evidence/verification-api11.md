# Engineering log entry for the AVION 0.1 build (SDK API 11)

Copied verbatim from PROJECT_STATE.md.

## 2026-11-04: the window's view stabilised, tensors while paused and in HDR, the telemetry module's memory, the speed test's false mark: SDK API 11 (Claude)

Directive: "WINDOWED VIRTUAL-IMU VIDEO STABILIZATION, PAUSED & HDR-CORRECT WINDOWED TENSOR EXPORT, TELEMETRY MEMORY DIET, AND `playback_speed_test` CLOCK FLUSH". Codex resident, idle (no file of it changed). `MEDIA_API_VERSION 11u`; struct sizes unchanged.

**A. The window's view stabilised** ([picture](docs/picture.md#stabilising-the-window-2026-11-04)). Alt+S, "stabilize video" / "ייצב תמונה" / "stabiliser la vidéo" in nine languages ([intents](docs/intents.md#stabilisation-2026-11-04)), `media_engine_set_stabilization` in the window.
- Each picture is measured before it is converted (`D3D12Renderer::Measure`): its grid in a list of its own into its slot's readback, the virtual IMU on perception's thread (`Steady`), `video::Stabilizer` for the view; the pacing waits on the fence and the thread's event (`ConvertBlock::Steadying`). The conversion then reconstructs the steadied view through `kRotate`'s affine map, so nothing is enlarged after the reconstruction (the blit alternative was rejected for that).
- Decode order: `Stabilizer::PushDecoded` (a B-picture takes the low-pass at its own time), `VirtualImu::ForgetMotion` (the search about no motion when the order reverses).
- The low-pass is now a second-order Butterworth of the same 0.35 s delay, host mode included: the first runs left 2.84 px rms, exactly a one-pole's 19 % of the 2.3 Hz shake; now 7.8 %, a pan's lag 0.348 s.
- The grid is reused by tracking, warm perception and the event camera, whose motion is the one measured.

**B. Tensors** ([while paused](docs/picture.md#tensors-while-paused-2026-11-04), [HDR](docs/picture.md#hdr-tensors-2026-11-04)).
- While paused: from the held source (`HeldTensor`, nothing decoded, `MEDIA_TENSOR_HELD`) or by one refresh landing that holds it from then on; a host that has exported a tensor has the picture held from the start of each pause. Keeping every source was not done: 400 MB at 4K (paused re-conversion's measurement).
- HDR: a PQ or HLG picture's elements are what the screen shows (`video::HdrToDisplay`, the shader's `Convert` in double, with the conversion's own source peak copied after the means), `MEDIA_TENSOR_TONE_MAPPED`.

**C. The telemetry module** ([memory](docs/picture.md#the-telemetry-modules-memory-2026-11-04)): 3,392 KiB to 1,408 KiB, 1,372 KiB used on a 4K file. The event camera shares one scratch plane, reads a scale-1 picture in place, packs events into 8 bytes (a 36-bit timestamp, exact), and the window's ring holds 32,768; the virtual IMU's grids are 16-bit. Not one event moved.

**D. The speed test's 92 and 119 ms marks** ([audio](docs/audio-dsp.md#playback-speed-2026-10-20)): the test's probe, not the audio. It counted a quiet run across a frame step's seek, so a mark cut short by the step, plus the new timeline's fade-in, read as a dip at the new timeline's start. The arithmetic gives 119 and 92 exactly for the grid's phases. 30 runs under load found no wrong mark; forcing the condition failed 8 of 8, and with the fix passed 8 of 8 at 0.0 ms. The WSOLA tail and the clock's anchor were not involved. The test now forces the condition every run.

**Tests.** 210 registered (+2: `media_make_shaken_fixture`, `media_playback_stabilize_test`). Extended: `media_tensor_export_tests` (paused against host mode and a snapshot of the screen, a later pause held, the HDR arithmetic, the PQ fixture against the screen, the SDK's stabilisation call; it now takes the PQ fixture too), `media_neuromorphic_spike_tests` (the packed ring across its wrap and a seek back, the region under 1.5 MiB), `media_vibrometry_tests` (decode order, the low-pass), `media_rotation_tests` (the stabilisation phrases), `media_c_api_tests` (API 11), `media_playback_speed_test` (the forced mark).

**Measured.**
- Stabilisation (480x272 shaken clip, 11.6 samples rms): on screen 14.73 px rms as it comes, **0.92 px rms** stabilised (the filter predicted 0.94), 15.81 after Alt+S; 0 dropped, 0 allocations. Real footage stabilised for 3.7 s: 720p59.94 H.264 with B-pictures 0 of 958 dropped, 4K60 Main10 PQ 0 of 956. Decode order: 0.50 samples rms from presentation order's view, 0.25 of a 6.53-sample shake left.
- Paused tensors: the picture on screen, 0.000000 from host mode's export, a snapshot's luma within 0.0008; the second export 3.3 to 15.6 ms, held, identical, 0 allocations.
- HDR tensors: PQ 58 cd/m² gives 0.5933 = (58/203)^(1/2.4) (its coded 0.454 before); the PQ fixture within 0.0143 of the screen.
- Telemetry: 1.340 MiB of 1.375 at 4K (was 3,392 KiB); the window's event test 54,088 events, 100.00 % on the squares, 0 dropped.

**Verified.**
- MSVC x64 `/W4 /WX`, Release and Debug: every target builds clean.
- Release (final code, 1,084 s, serial): 210 of 210. Debug (final code, 1,887 s, serial): 210 of 210. An earlier Release run (before a shutdown fix of mine: a measurement asked of a stopped perception thread would have been waited for forever at close) was 210 of 210 too. Chrome was running throughout.
- GCC 13.3 (WSL Ubuntu 24.04): 48 portable builds, 96 result lines (`-O2` and ASan/UBSan), every one passing, no compiler warning (2,199 s).
- 0 new dependencies; 0 allocations while stabilising, in the paused and HDR exports, and in the packed ring's polls.

**Open.**
- Stabilisation is one translation and one turn of the whole picture (no rolling shutter, no parallax), held at the 10 % margin, edge-directed (no neural reconstruction on a turned view), and one grid pass more a picture. A near-black picture is measured rarely (19 of 221 on the LG demo).
- The first tensor export of a host's first pause decodes the picture once (up to 0.18 s on 4K Main10). Host mode's tensors stay BT.709 8-bit.
- The window's event ring is 32,768 events: a host must poll before that many pile up.

## 2026-11-02 (night): AVION 0.1 launch package: logo, GitHub Pages site, whitepaper, social card, posts, evaluation bundle (Claude)

Directive: "AVION 0.1 — OFFICIAL RELEASE MARKETING SUITE". No engine code changed.

- **Brand** (`artifacts/marketing/`): `avion-01-mark.svg` / `-icon.svg` / `-logo.svg` (on obsidian) / `-logo-transparent.svg`, PNG renders (logo 3840x1120, mark and icon 1024). The mark: the developer emblem's chamfered cyan blade as the vertical of a reticle, a two-face prism "A", cyan horizon ticks.
- **Site** (`docs/site/`, publish `/docs/site` or copy to `/docs` for GitHub Pages; `.nojekyll` present): `index.html` (verification counters, five SVG charts drawn by inline script, capability table, MathML derivations, limits) and `whitepaper.html`. No external request of any kind. Every figure is from this log; charts compare AVION with its own baseline only.
- **Social** : `avion-0.1-x.png` (3200x1800, source `avion-0.1-x-card.html`), `X_POST.md` (8 posts, each ≤ 280 counting a URL as 23), `LINKEDIN_POST.md` (~2,900 characters with a URL).
- **Bundle** (`artifacts/share/`): `AVION-0.1-Evaluation/` (new `RELEASE_READINESS.md`, `EVALUATION_BRIEF.md`; `c_api.h`, `docs/sdk.md`, the Release demo and 23 static libraries, `playback_fixture.mp4`, the 210/210 Release `LastTest.log`, this log's API 11 entry), `AVION-0.1-Evaluation.zip` (5,626,179 bytes, SHA-256 ae081e3646968ba80c5263b1160c306aed9fa47f66e9567b812963f70787a1c2, deterministic entry dates) and `AVION-0.1-delivery-manifest.json` (bytes and SHA-256 of all 26 files; integrity only, not a signature). Rebuild: the script recorded in memory; any change to a bundled file changes the zip's digest, which the site, card and posts quote.
- **Left out on purpose**: competitor figures (allocations/s, decode µs for FFmpeg, OpenCV, GStreamer, ROS2, VLC, mpv) were never measured here, and neither was "bit-exact parity" between MSVC and GCC; "world's first" is not claimed. Corrected from the directive: audio zoom is −10.3 dB on the off-focus source (not +10.3 dB of gain), hum −41.8 to −48.5 dB, module memory today 48.4 MiB / 5 threads (47.1 MiB / 3 was the 2026-10-21 measurement), TTC = 2 / div.

## 2026-11-02 (late night): a measured head-to-head (ffmpeg, OpenCV, ffplay, VLC), the launch suite redesigned, a cut-confirmation defect found (Claude)

Directive: "COMPLETE VISUAL & EDITORIAL REDESIGN … MEASURED HEAD-TO-HEAD INDUSTRY BENCHMARKS". No engine source changed.

**Benchmark** ([docs/benchmarks.md](docs/benchmarks.md), generated; raw lines in `build/bench/`). Tools: `tools/bench_headtohead.cpp` (`media_bench_headtohead`, CMake target; portable: `scan` = IsobmffParser tables + `codec::BitstreamPerception` over the file's samples, `flow` = `video::Perception`, `survey` = `video::HorizonLevel` at each SIMD level), `tools/bench/malloc_count.c` (LD_PRELOAD, counts every malloc/calloc/realloc/aligned call), `tools/bench/opencv_baseline.cpp` (DIS ultrafast/fast, Farnebäck, Scharr + products + INTER_AREA block means; outputs reused), `tools/bench/run_linux.sh` (WSL: GCC 15.2, ffmpeg 8.0.1, OpenCV 4.10.0 installed with apt for this), `tools/bench/run_windows.py` (MSVC harness, ffmpeg 9.0.2 software and D3D11VA, players by GetProcessTimes), `tools/bench/report.py` → `build/bench/summary.json`. Inputs: `lg_black_4k60_hdr.mp4` (HEVC Main10 4K) and `costa_rica_4k60_hdr.mp4` (H.264 720p59.94 despite its name), first 3,000 pictures; 600 grey 640×480 pictures of the second.

**Measured** (i7-10700; Linux = WSL2 on the same CPU):
- Heap allocations per 1,000 pictures, same counter: AVION 0 (scan, flow, survey); ffmpeg decode + scdet 132,297 (4K HEVC) and 149,775 (720p); OpenCV DIS ultrafast 20,000, DIS fast 572,000, Farnebäck 227,000; OpenCV survey 52,000.
- CPU per picture, one core: scan 0.236 µs (4K) / 0.235 µs (720p) against ffmpeg decode 29.7 ms / 1.74 ms; flow 0.499 ms against DIS ultrafast 4.04 ms (Farnebäck 57.9); survey AVX2 0.171 ms against OpenCV 0.733 ms. MSVC harness: scan 0.208 / 0.410 µs, flow 0.497 ms, survey 0.134 ms.
- ffmpeg with D3D11VA was slower than software for this scan on the UHD 630 (4K: 35.9 ms wall a picture against 8.1 ms): the pictures are copied back for scdet.
- Players, 720p clip, sound at zero volume, % of one core: playing AVION demo 16.87, ffplay 44.53, VLC 8.28; paused AVION 1.17, ffplay 1.25, VLC started paused 0.00. **VLC beats the demo on both**; how much the demo's always-on modules account for was not measured.

**Defect found (open).** On `lg_black_4k60_hdr.mp4` the bitstream inspector raises 258 cut candidates and confirms 252 in 3,000 pictures; ffmpeg's scdet reports 3 (keyframes every 248 pictures, so not IDRs). On the 720p film the candidates (8) match scdet's 8 and 1 is confirmed. Cost figures are unaffected; the revision rule needs investigation on dark, dense reels.

**Pitfalls met.** `-frames:v` counts *output* frames: with `select` ffmpeg decoded whole files (use `scdet`, which passes every frame). The harness reads argv as UTF-8, so Windows runs need relative paths (ANSI "Développement"). The portable FileBlockSource's 1 MiB blocks refuse a 4K HEVC track (largest sample): the harness wraps it (`WholeSamples`) and reads samples with ReadAt. An early Windows scan (0.56 µs) ran during the apt install: discard timings taken while anything else runs.

**Launch suite redesigned** (warm paper / charcoal / clay / slate, obsidian dark mode with toggle; Newsreader, Plus Jakarta Sans, JetBrains Mono self-hosted under OFL in `docs/site/assets/fonts`). New mark: a woven "A" with a wing through it (under the left leg, over the right), `artifacts/marketing/avion-01-*.svg/png` (lockup outlined from the fonts; light/dark/icon). Templates in `tools/site/` (index, whitepaper, card, benchmarks.md, X_POST.md, LINKEDIN_POST.md, site.css) rendered by `tools/site/build_site.py` from summary.json (a missing figure stops the build). Order: `build_site.py --docs` → `tools/release/build_bundle.py` → `build_site.py` → card PNGs. Bundle now 37 files, 5,836,316 bytes, SHA-256 48a06844539881f78600780a33d07a0c667846b139cb093d7f873a671f34d7ff (adds `benchmarks/` and `bin/media_bench_headtohead.exe`). `OPENART_LOGO_PROMPTS.md`: five prompts for brand variations.

## 2026-11-03: the head-to-head's two findings fixed in the engine (hierarchical-GOP cuts, the polling pause), measured again (Claude)

Directive: "FIX THE TWO BENCHMARK FINDINGS ... RE-RUN HEAD-TO-HEAD & REGENERATE LAUNCH SUITE". Records: docs/picture.md "On a real reel: the hierarchical GOP and the encoder's clock", docs/session.md "The settled pause", docs/benchmarks.md (regenerated).

**1. 252 false cuts on `lg_black_4k60_hdr.mp4`.** Read picture by picture (`media_bench_headtohead scan <file> <n> frames`):
- every inter picture is a B slice at QP 26, in random-access mini-GOPs of 4 (an anchor predicted from 4 back, then 2, 1, 1), the anchor costing 3-5x the others. One mean for every B picture read each anchor as a burst, and the cheap next picture "confirmed" it;
- IDRs on a fixed 248-picture clock, through fades from black (5-14x between keys), scored 0.85.

Fix in `codec::BitstreamPerception`:
- `BitstreamFrame::reference_distance` / `layer` (from the slice's short-term set; HEVC temporal id, H.264 nal_ref_idc);
- a mean and a pending cut per class (P/B x distance octave, else layer, 16 classes);
- the burst term moved from 2-5x to 1.5-3x;
- in a hierarchical GOP a picture narrower than its anchor counts only if the anchor rose too (a flash on one leaf at 467, checked by eye);
- an IDR on the beat scores at most `kClockKey` 0.4.

Result, scored against scdet within 4 pictures (`report.py`: `cuts_matched`/`missed`/`extra`):
- LG: 765, 1325, 2125 against scdet's 765, 2128, 2612. Found 2; missed 2612, a cut from churning bubbles to slow honey where every class's cost falls (the inspector reads rises); extra 1325, a still teapot, checked by eye on an ffmpeg contact sheet.
- costa unchanged: 7 of 8 (410 missed, 1716 extra).
- 0.22-0.34 µs a picture.

New `TestHierarchy` in suite #203: the reel's shape gives 1 cut at the true anchor, flash 0.00, clock IDRs at most 0.40. Mutations fail it: one class per type gives 47 cuts; no cap gives IDRs at 0.85.

**2. Player CPU.** Engine threads are now named (`media worker`, `media window`, `media perception`, `media voice`, `media snapshot`); `tools/bench/thread_cpu.py` gives per-thread CPU.

Paused 1.17 % was two pollers: the presentation thread advanced still controls every 8.3 ms, and the worker's paused timer was 10 ms. Now a *settled* pause sleeps 250 ms on both:
- settled = no picture due, controls drawn and nothing timed in them (`KineticHud::Settled`), no GPU submission outstanding;
- input, pictures, commands, `RequestStop`, voice commands and scripted deadlines wake it;
- `PlaybackOptions::settled_sleep`, off in demo test modes that poll a paused player; `--test-pacing` requires 3 or more settled waits (15 measured).

Measured paused: 0.00-0.08 % (demo), against VLC started paused 0.00.

Playing, per thread (costa 60 fps): presentation 8-10 %, worker 5-7 %, perception 0.3-0.8 %.
- The user's hypothesis (heavy perception every frame) was wrong: perception already runs one warm grid per 100 ms when nothing asks for it. It costs about 3 points in per-thread A/B; `PlaybackOptions::warm_perception` / demo `--no-perception` turns it off.
- Most of the presentation share is the 1.2 ms spin before each deadline. A/B: at 0.8 ms spin, 1-9 of ~600 wakes land past the deadline; at 0.5 ms, 34-156. Kept at 1.2 ms. The `Pacing:` line now counts "past the deadline".
- Benchmark run: AVION 12.50 % (perception live) and 12.66 % (alone) against VLC 7.81 % and ffplay 36.56 %. **VLC still wins playing.**

**Verification**, from the logs (summary.json `suites`):
- Release 208/210 + 1 skipped (vad: other audio) + 1 failed: `media_fixture_neural_reuse_test`. It failed alone too, with GPU per neural conversion 14.6-15.4 ms (13.8 documented) and Chrome decoding video on the iGPU. The 2026-11-02 binary (the bundle's) failed it the same way in interleaved runs (new pass/fail, old pass/fail), so it is not a regression.
- Debug 207/210 + the same skip, the same failure, and `media_fixture_pacing_60_test`: one drop 0.2 s after the scripted resume. It passed alone 3/3; 60 interleaved Release runs (30 with the settled sleep, 30 without) dropped 0. Over all runs: 2 drops in 72 with the sleep, 0 in 50 without, both drops while Chrome held the iGPU. A small effect is not excluded.
- GCC 96/96.

**Benchmarks re-run** (Linux in WSL distro `Ubuntu`, which has ffmpeg/OpenCV; Ubuntu-24.04 has only g++).
- The previous run is kept in build/bench/2026-11-02/ for the pages' before/after (`previous` in summary.json).
- The harness prints `frame_100ns` and `final_cuts`; run_linux.sh records scdet's `cut_times`; run_windows.py adds `avion_pure`.
- Site, whitepaper, cards, posts and docs/benchmarks.md regenerated; suite counts are no longer typed (`SU`).
- Bundle evidence renamed `evidence/ctest-release.log` (the run was not 210/210), with manifest verification lines from the logs.

## 2026-11-03 (evening): 0.45 ms pre-deadline spin, step-down cuts, tests robust to a browser on the iGPU, clean 210/210 (Claude)

Directive: "CLEAN 210/210 ZERO-FAILURE RUN, HIGH-RESOLUTION WAITABLE TIMER TO CUT THE 1.2 ms SPIN CPU, STEP-DOWN SCENE-CUT DETECTION". Then, after asking, the user's answer: do not close Chrome, make the suites pass while it decodes video on the iGPU. Records: docs/session.md "The pre-deadline spin", docs/picture.md "The step down", docs/neural.md "On a shared iGPU", docs/voice.md "Process loopback".

**Spin.** Both pacing timers were already `CREATE_WAITABLE_TIMER_HIGH_RESOLUTION`, since 2026-10-22; their lateness is what the spin covers. The spin is now `PlaybackOptions::pace_spin_us`, default 450 (the floor 1.5x it; demo `--pace-spin-us`). Measured on a quiet machine:
- 1,200 µs: presentation 8.3-10.6 %, 0-1 Presents past the deadline.
- 450 µs: 2.5-6.9 %, 25-30 % of Presents past it by 0.07-0.13 ms mean (1.25 ms most).
- 400 µs: 2.8-7.4 %.

0 drops in every run. The Pacing line counts how many Presents land past the deadline, and by how much. Resume already woke both threads (`RequestPause` runs on the presentation thread; `CommitControl` → `WakeWorker`); unchanged.

**Step-down cuts.** Two inter pictures, each 3.5x or more under their class's mean, within 4 pictures of each other, after a level held 30 pictures and busy (class mean ≥ 0.1 of intra). Non-busy leaves are neutral, and a dropped picture holds its class mean until the drop is decided.
- `kSustain` 8 (the directive's figure) read the platform encoders' 15-picture burst end as a cut at unit 56 in all 3 streams; 30 passes.
- LG now 765, 1325, 2125, 2613 against scdet's 765, 2128, 2612: 3 of 3 found, extra 1325. Costa unchanged.
- TestHierarchy adds a 15-picture burst (not a cut) and a 5x step down (found at its picture). Mutations fail: the rule off misses it; `kSustain` 0 fails the platform streams.

**A browser on the iGPU.**
- `media_fixture_neural_reuse_test` failed under Chrome's video with old and new builds alike. `D3D12_COMMAND_QUEUE_PRIORITY_HIGH` on the direct queue changed nothing (interleaved A/B under a steady ffmpeg D3D11VA decode), so it was not kept.
- The gate is now relative to the Off phase. It requires the reuse shares (exact ≥ 15 %, tolerant ≥ 30 %), GPU time (exact ≤ Off, tolerant ≤ 0.95 Off; measured 0.86-0.91), and drops (tolerant none or fewer than Off; exact ≤ Off + 5 points). It replaces "fits the budget → no drop", which assumed an idle GPU. It passed 5/5 under Chrome plus a 720p hardware decode and 2/2 under Chrome alone.
- `CaptureSource::ProcessLoopback` (`ActivateAudioInterfaceAsync`, process tree, mmdevapi) is used by `media_capture_tests` and `media_capture_vad_test`. With another process playing a 440 Hz tone, results were identical to a silent machine, with no skip.

**Verification**, with Chrome open on the iGPU throughout:
- Release 210/210 (1,116 s), Debug 210/210 (1,933 s): 0 failed, 0 skipped.
- GCC 96/96.

**Benchmarks re-run** (players, % of one core):
- playing: AVION 8.44 alone / 8.91 with perception; VLC 7.66; ffplay 23.90;
- paused: AVION 0.00 / 0.16; VLC started paused 0.00.

VLC still leads playing, by under a point. Pages, cards, posts and bundle regenerated from summary.json, with suite counts from the logs.

## 2026-11-03 (evening): the launch suite upgraded: numerals, four pillars, a real-output showcase, Hugging Face card, GitHub Pages (Claude)

Directive: "UPGRADE AVION 0.1 LAUNCH SUITE". No engine source changed; two C99 tools added on the public header.

- **Showcase made by the engine** (`tools/showcase/`): `avion_showcase.c` (`media_showcase`, C99, `c_api.h` only: host mode, live sensor, RGBA frames in; `media_engine_save_snapshot`, per-picture telemetry JSONL, event spikes out), `make_showcase.py` (scenes with their truth, runs, layout via `compose_showcase.py`) and `quickstart.c` (`media_quickstart`, the site's snippet; looming on 41 of 90 frames, TTC 1.60 s for ~1.58, 268,614 events, tensor 602,112 bytes; exit 0). Footage: Big Buck Bunny (CC BY 3.0); the costa/LG fixtures have no known licence for publication, so are not shown.
- **Measured in the showcase** (single runs, truth set by the script): shadow lift 1.0 + neural 2x, mean luma 30 → 69, 11.4 ms on the GPU; generated harbour tilted +4.00°: horizon +4.06° (+0.004° untilted), auto-level −4.1°, buoy at 1 m/s flagged on 24 frames from TTC 1.83 s, 1.24 s read for 1.33, median error 3.8 %; shaken cartoon: event camera 17.19 M unstabilised (ring dropped 11.76 M of them) → 1.71 M stabilised by the virtual IMU; pulse under shake 71.98 BPM (luma), 72.00 BPM pure Cr; virtual IMU 0.031 px rms off the applied shake.
- **Found on the way**: the horizon is unreliable on Big Buck Bunny's meadow (tilted 4°: +8.5 to +9.1°; untilted: none found; other BBB scenes inconsistent): published under Limits. A first generated harbour with fine (aliasing) wave stripes read 3.25° for 4°; coarse swell 4.05.
- **Corrected from the directive**: allocations 132,292 (132,297 was the 11-02 run), scan 0.23 µs vs 31.1 ms = 134,501× (0.24 / 29.7 / 123,750× were 11-02), flow 0.51 vs 4.35 ms = 8.5× (not 0.50 / 4.04 / 8.1×), survey 0.179 vs 0.779 ms; "0.03°" is per-tilt (0.00–0.06°), "+0.08 ms" is the CPU survey at 720p, not a GPU cost; TTC median 3.4 % (latest table; the proof card said 3.1); paused 0.00 % is playback alone (0.16 % with perception).
- **Pages** (`tools/site`): tabular lining numerals everywhere (`--figures`), four capability pillars, the tabbed showcase (wipe, event toggle, BPM and IMU readouts from showcase.json), download section, limits; new card (event preview + 5 rows), `plates.html` → `plate-*.png`, `HUGGINGFACE_README.md` / `HUGGINGFACE_POST.md`, X / LinkedIn posts; `render_cards.py` renders and checks lengths (X ≤ 239, LinkedIn 2,338).
- **Bundle**: + samples/quickstart.c, samples/avion_showcase.c, bin/media_quickstart.exe, bin/media_showcase.exe: 42 files, 8,993,906 bytes, SHA-256 56bb84a24716fd42de0125d2028866e1826627c438b4643ea1ea5e4e8e20e982.
- **Deployed**: https://github.com/5645hm-a11y/avion (public; `tools/release/stage_pages.py` → build/gh-pages-dist, refuses source files) → https://5645hm-a11y.github.io/avion/ (zip digest checked live). Artifact preview republished (version 5).
- **Open**: no licence published for the bundle (the HF card says so); the Hugging Face repo itself was not created.
