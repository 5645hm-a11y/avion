# Engineering log entries for the AVION 0.1 build (SDK API 12 and 13)

Copied verbatim from PROJECT_STATE.md.

## 2026-11-04: SDK API 12, embedding: AVION inside the host's window, commands and events across threads, avion.dll (Claude)

Directive (the user, after asking how other engines do it): developers should connect the engine to their own systems with their own design; "we are developing the engine of the future". `MEDIA_API_VERSION 12u`. Record: [sdk](docs/sdk.md#embedding-api-12-2026-11-03).

- **Inside the host's window** (`media_engine_config_t.parent_window`, appended; API 11's struct still accepted). `D3D12Renderer::SetParentWindow`, `CreateChild` (on the window thread, `WS_CHILD | WS_EX_NOPARENTNOTIFY`, the parent's DPI awareness) and a WinEvent hook (`EVENT_OBJECT_LOCATIONCHANGE`, out of context) that resizes the child when the parent changes size: no polling. Escape ignored; F, F11 and Alt+Enter counted for the host (`MEDIA_EVENT_FULLSCREEN_REQUEST`); the parent's destruction closes (`MEDIA_ENDED_CLOSED`).
- **Commands and events.** `PlaybackCoordinator::PostCommand` (an SPSC ring of 32, then `WakePresenter`; `Pace` checks the ring after its fence, so a paused, settled engine runs a command at once), `PollEvent` (SPSC ring of 256: OPENED, STATE, POSITION every 250 ms, SEEK_LANDED, COMMAND, FULLSCREEN_REQUEST, ENDED with its reason), `PublishedState` (atomics stored every pass: `media_engine_state` for the windowed engine, any thread). Host mode: posted commands drained by `media_engine_step`, each with its COMMAND event. `media_api_version()`.
- **avion.dll**: every function of `c_api.h` (53), exported through a module-definition file CMake writes from the header. Built under the engine's rules (`/W4 /WX`, static runtime: the global `^media_` rule was extended to it after a runtime-mix warning, LNK4098); it depends on Windows' libraries only.
- **Samples** (`samples/`, in the bundle): a .NET 8 WinForms player (`samples/csharp/AvionPlayer`, explicit x64 layouts, a drawn seek bar and volume, Fluent icons, fullscreen on request, `--capture` writes its own window off the screens) and a tkinter player (`samples/python/avion_player.py`, `--smoke`).

**Found on the way.** Creating a child sends its parent `WM_PARENTNOTIFY` synchronously: the Python sample's UI thread, waiting for open without pumping, held open 10 s, then open failed (stage 6). Fixed with `WS_EX_NOPARENTNOTIFY`; `media_embed_tests` now opens once with its UI thread asleep (263-286 ms). CTest's absolute fixture paths reach a C program's argv in the ANSI code page ("Développement"): the embedding tests take relative paths. `media_c_api_tests` asserted API 11 (updated).

**Measured** (`media_embed_tests` and `media_embed_dll_tests`, strict C99, the engine on its own thread inside a host window with its own UI thread; Release): the child 640x360 in the host's 640x360, then 960x540 after the host's resize; "volume down" while paused and settled answered in 0.04-0.09 ms; a refused command answered `MEDIA_ERROR_REFUSED`; Escape ignored, Alt+Enter a fullscreen request; played to the end (`MEDIA_ENDED_MEDIA`, 3.01 s); the host's window destroyed: ended 2-5 ms later; `media_engine_stop`: 2-3 ms; 0 allocations in the process over 500 ms of embedded playback (static build). The C# sample on `big_buck_bunny_4k60.mp4`: "go to 1:42" landed, its bar in agreement with the engine.

**Verified**: MSVC x64 `/W4 /WX`; Release 212/212 (1,112 s, serial; an earlier full run: 209 of 212, the three failures test-side: the API-version check and the ANSI paths, then fixed), Debug 212/212 (1,968 s), GCC 13.3 96/96 (`-O2` and ASan/UBSan), all with a browser open on the iGPU. 0 new dependencies.

**Open.** One engine per parent. Rendering into a host's own Direct3D texture (Unity, Unreal, WinUI compositors) and hardware decoding in host mode are next; NuGet and pip packages; a licence for the bundle.

## 2026-11-04: SDK API 13, texture output: the pictures into the host's own renderer (Claude)

Directive: "continuer", the roadmap's next step after embedding: game engines, compositors and 3D scenes (Unity, Unreal, WinUI) take the pictures as textures, not a window. `MEDIA_API_VERSION 13u`. Record: [sdk](docs/sdk.md#texture-output-api-13-2026-11-04).

- **Config** (API 12's reserved bytes, still 176): `output_flags = MEDIA_OUTPUT_TEXTURE`, `output_width` x `output_height` (16..8192); the windowed engine only, not with `parent_window`, unknown flags refused. The window is hidden, its input isolated.
- **D3D12Renderer**: instead of a swap chain, three committed `R8G8B8A8_UNORM` textures on a shared heap (common state between composites) with NT handles, a shared frames fence and a shared host fence. Each texture's state is an atomic (free, published, held, drawn) taken by compare-and-swap; the newest frame is one word (`value << 2 | index`); a newer publication frees a published texture the host never took. `Composite` claims a free texture whose last work retired, makes the queue wait for the host fence's release value, draws, signals and publishes; no Present. A resize (`media_engine_resize_output`, applied by the presentation thread) recreates the textures under a new generation.
- **SDK**: `media_engine_query_output_textures`, `acquire_output_frame`, `release_output_frame`, `resize_output` (57 exports); `MEDIA_ERROR_UNSUPPORTED` off Windows. The bindings check `media_api_version() >= 12`.

**Found on the way** (review, before the test): `AcquireOutput` took the frame's fence value from the word it loaded, but between that load and its compare-and-swap the engine may free, redraw and republish the same texture, so the host would wait for an older value and read a picture still being drawn. The value now lives in the texture's own slot, written before it is published. Test-side: the chapter fixture's scenes carry a 0-23 luma pattern and moving chroma, so the host test reads the mean BT.601 luma of the centre, not one red sample; handle values may be reused after a resize.

**Measured** (`media_texture_output_tests`, a Direct3D 11 host on the adapter the LUID names, Release): 218 frames into the host's texture in 9.0 s, sequences and fence values always rising; centre luma dark 17-34, bright 209-228, mid 117-127 (expected 23, 223, 123; none outside ±20), side bars black; resized to 256 x 144 at 4.5 s: generation 1 to 3, 107 frames after; 0 allocations in the process over a second of the host's calls (engine threads included).

**Verified**: MSVC x64 `/W4 /WX`; Release 213/213 (1,131 s, serial), Debug 213/213 (1,961 s), GCC 13.3 96/96 (`-O2` and ASan/UBSan). 0 new dependencies.

**Open.** A Unity or Unreal plug-in on this interface; FP16/HDR output (pictures are tone-mapped into 8 bits); hardware decoding in host mode; NuGet and pip packages; a licence for the bundle.
