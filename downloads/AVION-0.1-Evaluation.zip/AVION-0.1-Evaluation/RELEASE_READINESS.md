# AVION 0.1 — Release Readiness

**Product:** AVION 0.1, a deterministic perception, vision and media kernel (C99 SDK over C++20 / Direct3D 12).
**SDK:** `MEDIA_API_VERSION 11u` ([`include/media/c_api.h`](include/media/c_api.h)). Structs from API 5 onward are still accepted (each carries `struct_size`).
**Status:** ready for technical evaluation on Windows 10/11 x64. Not yet a general-availability release: see *Open items*.

## 1. Verification matrix

| Configuration | Result | Wall time | Notes |
|---|---|---|---|
| MSVC x64 `/W4 /WX`, Release, CTest serial (3 November 2026) | **210 of 210 passed**, 0 skipped, 0 failed | 1,116 s | Chrome open and using the iGPU (14-25 % of the 3D engine) throughout |
| MSVC x64 `/W4 /WX`, Debug, CTest serial | **210 of 210 passed**, 0 skipped, 0 failed | 1,933 s | The same |
| GCC 13.3, WSL Ubuntu 24.04, 48 portable suites × (`-O2`, ASan + UBSan) | **96 of 96 result lines passed**, no compiler warning | | The portable subset: core, demux, codecs' syntax, DSP, perception, SDK host mode … |

- Every target builds clean under `/W4 /WX` in both configurations.
- Generator: Visual Studio 18 2026, x64. Release flags `/O2 /Ob2 /DNDEBUG` (no `/GL`, so the static libraries link with other MSVC 14.x toolsets).
- Measurement machine: Intel Core i7-10700 with UHD 630 integrated graphics.
- Evidence in this bundle: `evidence/ctest-release.log` (CTest's own log of the Release run above: 210 passed, 0 failed, 0 skipped; its timestamps follow the machine's clock)  (the engineering log's entry for this build). The GCC runs kept no log file beyond that entry.

## 2. Architectural guarantees and how they are checked

| Guarantee | How it is enforced | How it is tested |
|---|---|---|
| No third-party code | Only Win32, COM, D3D12, DXGI, DirectComposition, Media Foundation MFTs and WASAPI on Windows; C++20 standard library elsewhere | Build files list no external package |
| No heap allocation in steady state | `LinearMemoryArena` regions committed in *Preparing*, sealed before *Primed*; a request after sealing fails | Allocation probes in the suites report 0 allocations while playing, stabilising, tracking, exporting tensors, polling events |
| No locks on real-time paths | Stages exchange 64-byte descriptors through SPSC rings with acquire/release cursors on separate cache lines | Unit tests of the rings; playback suites under load |
| Opt-out modules cost nothing | Each module is one fixed arena region plus its threads; left out, neither exists | `media_c_api_tests` compares capacity, bytes in use and thread count |

## 3. Tests with a history of intermittency

All passed in the final runs above. They are listed so an evaluator who sees one fail knows its history.

| Test | History | Current state |
|---|---|---|
| `media_fixture_lg_hdr_cold_start_test` | ~4 % of 4K60 HDR cold starts dropped pictures on the UHD 630 | Governor "thin-queue rule": 0 of 200 direct starts dropped since; the trigger itself was never identified |
| `media_playback_speed_test` | Occasional 92 / 119 ms audio mark | Root cause was the test's probe counting across a frame-step seek; probe fixed and the condition is now forced every run (8 of 8 at 0.0 ms) |
| `media_playback_ab_loop_test` | A pinned A–B turn occasionally over its 5 ms budget | Landings staged 150 ms ahead: 0.19–3.76 ms, 4 of 4 runs |
| `media_fixture_neural_reuse_test` | Fails while another process decodes video on the same integrated GPU (15.4 ms against a 14.2 ms budget) | Passes on a quiet GPU; still sensitive to GPU contention |

## 4. Open items

- **Stabilisation** is one translation and one rotation of the whole picture: no rolling-shutter or parallax correction. It is held at a 10 % margin and uses edge-directed (not neural) reconstruction on a rotated view.
- **Tensors:** a host's first export in its first pause decodes the picture once (up to 0.18 s on 4K Main10). Host-mode tensors are BT.709 8-bit.
- **Event camera (windowed):** the ring holds 32,768 events; a host must poll before that many accumulate.
- **Tracking:** an object hidden behind another for longer than 0.5 s loses its track.
- **Formats:** MP4 with H.264 or HEVC video and AAC or PCM audio. AV1 is refused. The platform AAC decoder takes at most 6 channels (7.1 is refused).
- **Platforms:** Windows playback is fully exercised. Host mode builds and passes on Linux (GCC). Android and Apple toolchains have not been executed.

- **Bitstream cuts** (found by the head-to-head on 2 November 2026, fixed on 3 November): the inspector had confirmed 252 cuts on LG's 4K reel, reading its hierarchical GOP and clock-scheduled keyframes as cuts. It now finds 3 of `scdet`'s 3 there (one by a rule for cuts into cheaper shots), with 1 extra, and 7 of 8 on the 720p film (`benchmarks/benchmarks.md`). It sees costs, not pixels: a cut exactly on a scheduled keyframe can be missed, and a burst of new detail that lasts over half a second and stops at once can read as a cut.

## 5. Head-to-head and what this release does not claim

- `benchmarks/benchmarks.md` reports a measured comparison on the machine above: AVION against ffmpeg (decode + `scdet`), OpenCV (DIS and Farnebäck flow, a Scharr structure tensor), ffplay and VLC. It uses the same inputs for every program and the same allocation counter for every Linux process. The raw results, the summary and every script are in `benchmarks/`.
- Cut accuracy is scored against `scdet` on two files only (a sanity check, not a recall figure), and the motion rows compare AVION's tile flow with dense per-pixel flow; the report states both.
- The delivery manifest lists SHA-256 digests for integrity. It is not a cryptographic signature.
