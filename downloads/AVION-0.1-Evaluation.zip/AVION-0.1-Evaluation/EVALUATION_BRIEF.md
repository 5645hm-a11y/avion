# AVION 0.1 — Evaluation Brief

AVION 0.1 is a media and perception kernel for Windows (Direct3D 12) with a portable host mode. One C99 header gives a host file playback, live camera and microphone ingest, stabilisation, multi-object tracking, time-to-contact, remote vibrometry, an event-camera emulation, bitstream inspection and tensor export. It uses no third-party library, and allocates nothing on the heap once playing.

This brief tells an evaluator what is in the bundle, how to see it work in five minutes, and which numbers to check.

## 1. Contents

| Path | What it is |
|---|---|
| `EVALUATION_BRIEF.md` | This document |
| `RELEASE_READINESS.md` | Verification matrix, test history, open items |
| `LICENSE.md` | The AVION Evaluation & Commercial SDK License: free for evaluation, benchmarking, academic research and non-commercial prototyping; production deployment and commercial redistribution need a commercial licence |
| `include/media/c_api.h` | The whole SDK: C99, opaque handle, host-provided storage |
| `docs/sdk.md` | SDK reference: lifecycle, modules, every API version's additions |
| `bin/media_player_demo.exe` | The windowed engine (Release, x64) |
| `lib/*.lib` | Release static libraries (MSVC x64, no `/GL`); link `media_sdk.lib` and its dependencies |
| `samples/playback_fixture.mp4` | A short generated H.264 + AAC test clip |
| `evidence/` | CTest log of this build's Release run (221/221 passed); the engineering log entries for this build (APIs 12-14) |
| `benchmarks/` | The head-to-head against ffmpeg, OpenCV, ffplay and VLC: report, raw results, summary, scripts |
| `bin/media_bench_headtohead.exe` | AVION's side of the head-to-head (`scan`, `flow`, `survey`) |
| `bin/avion.dll` (`lib/avion.lib`) | SDK API 17 (Matroska/WebM, AV1 through Windows' decoder, host-mode tracks, snapshots into memory; API 14 had 58 exports): the whole C99 SDK as a DLL for any language: inside your window (API 12), into your renderer's Direct3D 11/12 textures in 8-bit, 10-bit PQ or FP16 scRGB (APIs 13-14), or host-driven with the GPU decoding into them (API 14); Windows' own libraries only |
| `packages/avion-0.1.0-py3-none-win_amd64.whl` | Python: `pip install` it; `import avion` (telemetry, zero-copy tensors, event spikes, bitstream inspection, shared textures) |
| `packages/Avion.Sdk.0.1.0.nupkg` | .NET / Unity / C++: `Avion.Interop` (P/Invoke, `AvionHost`, `AvionWindow`), `avion.dll`, `avion.lib`, `c_api.h`, an MSBuild `.targets` |
| `samples/csharp/AvionPlayer`, `samples/python/avion_player.py` | Players whose controls are all their own, AVION inside: .NET 8 WinForms (`dotnet run -c Release -- video.mp4`) and Python tkinter (`python avion_player.py video.mp4`) |
| `samples/quickstart.c`, `bin/media_quickstart.exe` | The site's C99 quickstart: a camera in; perception, a tensor and event spikes out (exit 0 when it worked) |
| `samples/avion_showcase.c`, `bin/media_showcase.exe` | The C99 host that made the site's showcase pictures: raw RGBA frames in; snapshots, telemetry and spikes out |

The integrity of every file is recorded in `AVION-0.1-delivery-manifest.json`, which sits next to the archive (byte count and SHA-256 per file).

## 2. Five-minute check

Requirements: Windows 10 or 11 x64, a Direct3D 12 GPU with hardware H.264/HEVC decode, an audio output device.

```powershell
.\bin\media_player_demo.exe .\samples\playback_fixture.mp4
.\bin\media_player_demo.exe 'C:\Media\your-clip.mp4'   # any MP4 with H.264/HEVC + AAC
```

| Key | Action |
|---|---|
| Space | Play / pause |
| Ctrl+K | Command bar: type commands in nine languages ("next chapter", "stabilize video", "מטרה הבאה" …) |
| T, then Tab | Lock on the object under the reticle, then move to the next detected object |
| Alt+S | Stabilise the view (virtual IMU: no sensor needed) |
| Shift+R | Auto-level the horizon |
| S | Forensic snapshot: a BMP plus a JSON sidecar with its frame hash |

## 3. Integrating the SDK

```c
#include "media/c_api.h"

media_engine_config_t config;
media_engine_config_init(&config);            /* every module on; clear bits in config.modules to drop them */
void* storage = host_aligned_alloc(media_engine_storage_alignment(), media_engine_storage_bytes());
media_engine_t* engine = NULL;
media_engine_create(&config, storage, media_engine_storage_bytes(), &engine);
media_engine_open(engine, "clip.mp4");        /* or media_engine_open_sensor for a live camera + microphones */
media_engine_run(engine);                     /* windowed mode; host mode calls media_engine_step / pump_audio */
media_engine_close(engine);
media_engine_destroy(engine);
```

The host owns the engine's storage; the engine never calls `malloc`. Arena sizes are known before anything is created (`media_query_module_budget`). Leaving a module out removes its region and its threads exactly:

| Module | Arena region | Threads |
|---|---|---|
| Core (always) | 192 MiB (177.0 MiB measured on every fixture) | — |
| Voice | 12 MiB | 1 |
| HUD | 1.5 MiB | 2 |
| Subtitles | 32 MiB | 1 |
| Chapters | 1.5 MiB | 0 |
| Telemetry and perception | 1.375 MiB | 1 |
| Neural upscale | GPU resources only | 0 |

## 4. Numbers to check

Each was measured by an automated test on an i7-10700 with UHD 630 graphics.

| Area | Result |
|---|---|
| Test suites | 221/221 Release, 221/221 Debug (MSVC `/W4 /WX`, 0 failed, 0 skipped); 96/96 GCC 13.3 result lines (`-O2`, ASan + UBSan) |
| Texture output (API 13-14) | Direct3D 11 and Direct3D 12 hosts: 217-218 frames in 9 s, every scene's level right, resized live, 0 allocations; an HDR10 file reached the host at up to 5,849 cd/m² in the 10-bit PQ format |
| Host-mode hardware decoding (API 14) | H.264 and HEVC Main 10 decoded on the GPU into the shared textures while the host steps: 0.7 % of one core (1080p-class H.264), 6.8 % (4K HDR HEVC), seeks and resize, 0 allocations |
| Packages (API 14) | The wheel imported from its unpacked files: a 72.0 BPM pulse, zero-copy tensors, 9,473 event spikes in a second; the NuGet package in a fresh .NET 8 app: 72 frames from the hardware decoder |
| CPU while playing | 720p60 head-to-head: 8.44 % of one core for playback alone, 8.91 % with perception live (VLC 7.66 %, ffplay 23.90 %); 197–199 % with busy-spin pacing |
| CPU while paused | 0.00–0.08 % over 20 s (the settled pause, 3 November), against 191–200 % with busy-spin pacing |
| Window stabilisation | 14.73 px rms of shake on screen → 0.92 px rms (the filter predicted 0.94); 0 dropped |
| Virtual IMU | 0.068 px rms from the true shake, from pixels alone |
| Roll stabilisation | Horizon 0.25 px rms from level under ±5° at 7 Hz (4.28 unstabilised) |
| Auto-level | Tilts of +4.5 / −6.0 / 0 / +12 / −14° read as +4.48 / −6.00 / +0.03 / +11.90 / −14.02°; GPU statistics pass 0.32 → 0.40 ms at 4K |
| Remote vibrometry | 72.00 BPM pulse with and without camera shake (138 BPM if shake is not compensated); 8.000 Hz flicker and vibration |
| Event camera | A still scene under rolling shake: 141 stabilised events against 1,201,527 unstabilised |
| Bitstream inspection | 0.1–0.4 µs per picture (slice headers to QP, no decode); against ffmpeg's `scdet` on real reels: 3 of 3 cuts (4K HEVC), 7 of 8 (720p H.264) |
| Multi-object tracking | Up to 4 objects; two crossing objects keep their ids on 25 of 25 pictures after an X crossing |
| Audio zoom | Off-focus source −10.3 dB, focused source +0.9 dB |
| Hum notch | Drone and hum −41.8 to −48.5 dB; the voice's third-octave spectrum within 0.12 dB |
| Tensor export | NCHW float32 / float16; windowed and host exports identical (worst difference 0.000000) |

## 5. Limits to know before evaluating

See `RELEASE_READINESS.md` §4. In short:
- stabilisation is whole-frame only (no rolling shutter or parallax);
- MP4/MOV and MKV/WebM with H.264/HEVC (GPU) or AV1 (Windows' software decoder: about 4 cores at 4K60) + AAC/Opus/PCM (AAC ≤ 6 channels, Opus mono/stereo);
- Android and Apple toolchains have not yet been executed;
- the bitstream inspector sees costs, not pixels: a cut exactly on a scheduled keyframe can be missed.

The head-to-head with ffmpeg, OpenCV, ffplay and VLC is in `benchmarks/benchmarks.md`, with its caveats.

## 6. Verifying the bundle

```powershell
Get-FileHash .\AVION-0.1-Evaluation.zip -Algorithm SHA256
```

Compare with `archive.sha256` in `AVION-0.1-delivery-manifest.json`. After extracting, each file's digest is under `files`.
